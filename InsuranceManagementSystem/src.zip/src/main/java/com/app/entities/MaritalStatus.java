package com.app.entities;

public enum MaritalStatus {
	Single, Married
}
