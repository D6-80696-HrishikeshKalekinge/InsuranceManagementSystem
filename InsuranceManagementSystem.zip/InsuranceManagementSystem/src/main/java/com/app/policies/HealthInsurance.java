//package com.app.entities.policies;
//
//import java.util.List;
//
//import javax.persistence.CollectionTable;
//import javax.persistence.ElementCollection;
//import javax.persistence.Entity;
//import javax.persistence.Table;
//
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//
//@Entity
//@Table(name = "health_insurance_table")
//@AllArgsConstructor
//@NoArgsConstructor
//@Setter
//@Getter
//public class HealthInsurance extends Insurances {
//	
//	private String diseases;
//}



